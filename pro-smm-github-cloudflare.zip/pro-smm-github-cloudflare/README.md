# Pro SMM — GitHub Pages + Cloudflare Worker + D1

यह पैकेज आपके पुराने `index.html` का **वही UI/design** रखता है, लेकिन login, users, balance, deposits, orders और Telegram को browser `localStorage` से हटाकर Cloudflare Worker + D1 में ले जाता है। Telegram bot token अब frontend में नहीं है।

## 1) GitHub Pages
- `frontend/index.html` को अपने GitHub repository में upload करें।
- GitHub Pages enable करें।
- `index.html` में `API_BASE` को अपने Worker URL से बदलें:
  `https://YOUR-WORKER.your-subdomain.workers.dev`

## 2) Cloudflare D1
Cloudflare में D1 database बनाएं, नाम रखें `pro-smm-db`।
फिर `worker/schema.sql` चलाएं।
`worker/wrangler.toml` में `database_id` भरें।

## 3) Worker deploy
Cloudflare Workers project में `worker/src/index.js` और `wrangler.toml` रखें।
फिर:
```bash
npx wrangler login
npx wrangler d1 create pro-smm-db
npx wrangler d1 execute pro-smm-db --remote --file=worker/schema.sql
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler deploy
```
`ADMIN_CHAT_ID` में अपने Telegram private chat ID डालें। `FRONTEND_ORIGIN` में GitHub Pages का exact origin डालें।

## 4) Telegram webhook
Deploy के बाद browser में यह URL खोलें (TOKEN को URL में खुद डालें):
`https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://<WORKER-DOMAIN>/telegram/webhook`

Bot token को GitHub/frontend में कभी न डालें।

## 5) Admin commands
- `/approve TXNID`
- `/reject TXNID`
- `/complete ORDERID TRACKINGID`
- `/cancel ORDERID`
- `/users`

### जरूरी
पुराने HTML में bot token hard-coded था; उसे मैंने नए frontend में नहीं रखा है। यदि वह token असली है, Telegram BotFather से **token revoke/regenerate** करना सुरक्षित रहेगा।
